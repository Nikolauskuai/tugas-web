<?php
// function penjumlahan
function tambah($a, $b) {
    return $a + $b;
}

// function pengurangan
function kurang($a, $b) {
    return $a - $b;
}

// function hitung diskon
function hitungDiskon($harga, $diskon) {
    $potongan = $harga * ($diskon / 100);
    return $harga - $potongan;
}

// function format rupiah untuk tampilan hasil
function formatRupiah($value) {
    return 'Rp ' . number_format($value, 0, ',', '.');
}

// function membuat teks hasil perhitungan secara rapi
function buildHasil($penjumlahan, $pengurangan, $hargaDiskon) {
    return "Penjumlahan: <span class='highlight'>" . $penjumlahan . "</span><br>"
        . "Pengurangan: <span class='highlight'>" . $pengurangan . "</span><br>"
        . "Harga setelah diskon: <span class='highlight'>" . formatRupiah($hargaDiskon) . "</span>";
}
?>